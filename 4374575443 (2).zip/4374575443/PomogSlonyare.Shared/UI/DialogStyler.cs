using System.Reflection;
using System.Windows.Forms;

namespace PomogSlonyare.Shared.UI;

public static class DialogStyler
{
    public static void ApplySmoothDialog(Form form)
    {
        typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic)
            ?.SetValue(form, true);
        form.MaximizeBox = false;
        form.MinimizeBox = false;
        form.FormBorderStyle = FormBorderStyle.FixedSingle;
        form.Opacity = 0;

        void FadeIn(object? sender, EventArgs e)
        {
            form.Shown -= FadeIn;
            var timer = new System.Windows.Forms.Timer { Interval = 15 };
            timer.Tick += (_, _) =>
            {
                form.Opacity += 0.08;
                if (form.Opacity >= 1)
                {
                    form.Opacity = 1;
                    timer.Stop();
                    timer.Dispose();
                }
            };
            timer.Start();
        }

        form.Shown += FadeIn;
    }
}

