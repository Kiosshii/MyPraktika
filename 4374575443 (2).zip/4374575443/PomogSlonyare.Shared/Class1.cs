﻿namespace PomogSlonyare.Shared;

public static class AssemblyMarker { }
