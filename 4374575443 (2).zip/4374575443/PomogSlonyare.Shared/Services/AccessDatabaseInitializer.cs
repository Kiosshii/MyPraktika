using System.Data;
using System.Data.OleDb;

namespace PomogSlonyare.Shared.Services;

public static class AccessDatabaseInitializer
{
    private const string TemplateFileName = "PomogSlonyareData.mdb";
    private static readonly object Sync = new();
    private static bool _isReady;

    public static string EnsureDatabase(string? targetPath = null)
    {
        lock (Sync)
        {
            var resolvedPath = targetPath ?? GetDefaultPath();
            if (!File.Exists(resolvedPath))
            {
                CopyTemplate(resolvedPath);
            }

            if (!_isReady)
            {
                InitializeSchema(resolvedPath);
                _isReady = true;
            }

            return resolvedPath;
        }
    }

    public static string BuildConnectionString(string dbPath) =>
        $"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={dbPath};";

    private static string GetDefaultPath()
    {
        var root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "PomogSlonyare");
        Directory.CreateDirectory(root);
        return Path.Combine(root, TemplateFileName);
    }

    private static void CopyTemplate(string targetPath)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(targetPath)!);
        var template = Path.Combine(AppContext.BaseDirectory, TemplateFileName);
        if (!File.Exists(template))
        {
            throw new InvalidOperationException($"Не найден файл шаблона базы данных: {template}");
        }
        File.Copy(template, targetPath, overwrite: true);
    }

    private static void InitializeSchema(string dbPath)
    {
        using var connection = new OleDbConnection(BuildConnectionString(dbPath));
        connection.Open();

        EnsureUsersTable(connection);
        EnsureTicketsTable(connection);
        SeedData(connection);
    }

    private static void EnsureUsersTable(OleDbConnection connection)
    {
        if (TableExists(connection, "Users"))
        {
            return;
        }

        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE Users (
    ID COUNTER PRIMARY KEY,
    FullName TEXT(120),
    Email TEXT(120),
    PasswordHash TEXT(128),
    Role TEXT(20),
    Phone TEXT(50),
    CreatedAt DATETIME
)";
        cmd.ExecuteNonQuery();
    }

    private static void EnsureTicketsTable(OleDbConnection connection)
    {
        if (TableExists(connection, "Tickets"))
        {
            return;
        }

        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE Tickets (
    ID COUNTER PRIMARY KEY,
    Title TEXT(180),
    Description MEMO,
    Status TEXT(40),
    Priority TEXT(20),
    UserID LONG,
    CreatedAt DATETIME,
    UpdatedAt DATETIME
)";
        cmd.ExecuteNonQuery();
    }

    private static void SeedData(OleDbConnection connection)
    {
        using var countCmd = connection.CreateCommand();
        countCmd.CommandText = "SELECT COUNT(*) FROM Users";
        var usersCount = Convert.ToInt32(countCmd.ExecuteScalar());
        if (usersCount > 0)
        {
            return;
        }

        var now = DateTime.Now;
        var users = new (string FullName, string Email, string Password, string Role, string Phone)[]
        {
            ("Главный Слоняр", "admin@pomogslonyare.local", "admin123", "admin", "+7 999 000 0000"),
            ("Алексей Клиент", "alexey@example.com", "clientpass", "user", "+7 900 123 4567"),
            ("Мария Клиент", "maria@example.com", "clientpass", "user", "+7 921 222 3344")
        };

        foreach (var user in users)
        {
            using var insert = connection.CreateCommand();
            insert.CommandText = @"INSERT INTO Users (FullName, Email, PasswordHash, Role, Phone, CreatedAt)
VALUES (?, ?, ?, ?, ?, ?)";
            insert.Parameters.Add("@FullName", OleDbType.VarWChar, 120).Value = user.FullName;
            insert.Parameters.Add("@Email", OleDbType.VarWChar, 120).Value = user.Email;
            insert.Parameters.Add("@PasswordHash", OleDbType.VarWChar, 128).Value = user.Password;
            insert.Parameters.Add("@Role", OleDbType.VarWChar, 20).Value = user.Role;
            insert.Parameters.Add("@Phone", OleDbType.VarWChar, 50).Value = user.Phone;
            insert.Parameters.Add("@CreatedAt", OleDbType.Date).Value = now;
            insert.ExecuteNonQuery();
        }

        // Fetch ids for seeding tickets
        var usersMap = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        using (var reader = new OleDbCommand("SELECT ID, Email FROM Users", connection).ExecuteReader())
        {
            while (reader != null && reader.Read())
            {
                usersMap[reader["Email"].ToString() ?? string.Empty] = Convert.ToInt32(reader["ID"]);
            }
        }

        var tickets = new (string Title, string Description, string Status, string Priority, string Email)[]
        {
            ("Не работает почта", "Письма не отправляются со вчерашнего дня", "open", "high", "alexey@example.com"),
            ("Ошибка авторизации", "Система сбрасывает пароль при входе", "in_progress", "normal", "maria@example.com"),
            ("Нужен доступ к VPN", "Новый сотрудник не может подключиться к корпоративному VPN", "open", "low", "alexey@example.com")
        };

        foreach (var ticket in tickets)
        {
            if (!usersMap.TryGetValue(ticket.Email, out var userId))
            {
                continue;
            }

            using var insertTicket = connection.CreateCommand();
            insertTicket.CommandText = @"INSERT INTO Tickets (Title, Description, Status, Priority, UserID, CreatedAt, UpdatedAt)
VALUES (?, ?, ?, ?, ?, ?, ?)";
            insertTicket.Parameters.Add("@Title", OleDbType.VarWChar, 180).Value = ticket.Title;
            insertTicket.Parameters.Add("@Description", OleDbType.LongVarWChar).Value = ticket.Description;
            insertTicket.Parameters.Add("@Status", OleDbType.VarWChar, 40).Value = ticket.Status;
            insertTicket.Parameters.Add("@Priority", OleDbType.VarWChar, 20).Value = ticket.Priority;
            insertTicket.Parameters.Add("@UserID", OleDbType.Integer).Value = userId;
            insertTicket.Parameters.Add("@CreatedAt", OleDbType.Date).Value = now;
            insertTicket.Parameters.Add("@UpdatedAt", OleDbType.Date).Value = now;
            insertTicket.ExecuteNonQuery();
        }
    }

    private static bool TableExists(OleDbConnection connection, string tableName)
    {
        using var schema = connection.GetSchema("Tables", new[] { null, null, tableName, null });
        return schema.Rows.Count > 0;
    }
}

