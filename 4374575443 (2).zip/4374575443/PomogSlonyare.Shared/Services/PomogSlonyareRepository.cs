using System.Data;
using System.Data.OleDb;
using PomogSlonyare.Shared.Models;

namespace PomogSlonyare.Shared.Services;

public sealed class PomogSlonyareRepository
{
    private readonly string _connectionString;

    public PomogSlonyareRepository(string? dbPath = null)
    {
        var path = AccessDatabaseInitializer.EnsureDatabase(dbPath);
        _connectionString = AccessDatabaseInitializer.BuildConnectionString(path);
    }

    public IReadOnlyList<UserDto> GetUsers(string? role = null)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();

        command.CommandText = @"
SELECT ID, FullName, Email, Role, Phone, CreatedAt
FROM Users";

        if (!string.IsNullOrWhiteSpace(role))
        {
            command.CommandText += " WHERE Role = ?";
            command.Parameters.AddWithValue("@Role", role);
        }

        command.CommandText += " ORDER BY CreatedAt DESC";
        using var reader = command.ExecuteReader();
        var result = new List<UserDto>();
        while (reader != null && reader.Read())
        {
            result.Add(MapUser(reader));
        }

        return result;
    }

    public UserDto? Authenticate(string email, string password)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
SELECT ID, FullName, Email, Role, Phone, CreatedAt
FROM Users
WHERE Email = ? AND PasswordHash = ?";
        command.Parameters.AddWithValue("@Email", email);
        command.Parameters.AddWithValue("@PasswordHash", password);
        using var reader = command.ExecuteReader(CommandBehavior.SingleRow);
        return reader != null && reader.Read() ? MapUser(reader) : null;
    }

    public UserDto CreateUser(string fullName, string email, string password, string role, string? phone)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"INSERT INTO Users (FullName, Email, PasswordHash, Role, Phone, CreatedAt)
VALUES (?, ?, ?, ?, ?, ?)";
        command.Parameters.Add("@FullName", OleDbType.VarWChar, 120).Value = fullName;
        command.Parameters.Add("@Email", OleDbType.VarWChar, 120).Value = email;
        command.Parameters.Add("@PasswordHash", OleDbType.VarWChar, 128).Value = password;
        command.Parameters.Add("@Role", OleDbType.VarWChar, 20).Value = role;
        command.Parameters.Add("@Phone", OleDbType.VarWChar, 50).Value = (object?)phone ?? DBNull.Value;
        command.Parameters.Add("@CreatedAt", OleDbType.Date).Value = DateTime.Now;
        command.ExecuteNonQuery();

        var id = GetIdentity(connection);
        return GetUserById(connection, id)!;
    }

    public UserDto? UpdateUser(int userId, string fullName, string email, string role, string? phone, string? newPassword)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        var sql = "UPDATE Users SET FullName = ?, Email = ?, Role = ?, Phone = ?";
        if (!string.IsNullOrWhiteSpace(newPassword))
        {
            sql += ", PasswordHash = ?";
        }
        sql += " WHERE ID = ?";
        command.CommandText = sql;
        command.Parameters.Add("@FullName", OleDbType.VarWChar, 120).Value = fullName;
        command.Parameters.Add("@Email", OleDbType.VarWChar, 120).Value = email;
        command.Parameters.Add("@Role", OleDbType.VarWChar, 20).Value = role;
        command.Parameters.Add("@Phone", OleDbType.VarWChar, 50).Value = (object?)phone ?? DBNull.Value;
        if (!string.IsNullOrWhiteSpace(newPassword))
        {
            command.Parameters.Add("@PasswordHash", OleDbType.VarWChar, 128).Value = newPassword;
        }
        command.Parameters.Add("@ID", OleDbType.Integer).Value = userId;
        command.ExecuteNonQuery();

        return GetUserById(connection, userId);
    }

    public void DeleteUser(int userId)
    {
        using var connection = OpenConnection();

        using (var deleteTickets = connection.CreateCommand())
        {
            deleteTickets.CommandText = "DELETE FROM Tickets WHERE UserID = ?";
            deleteTickets.Parameters.AddWithValue("@UserID", userId);
            deleteTickets.ExecuteNonQuery();
        }

        using var deleteUser = connection.CreateCommand();
        deleteUser.CommandText = "DELETE FROM Users WHERE ID = ?";
        deleteUser.Parameters.AddWithValue("@ID", userId);
        deleteUser.ExecuteNonQuery();
    }

    public IReadOnlyList<TicketDto> GetTickets(int? userId = null)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
SELECT t.ID, t.Title, t.Description, t.Status, t.Priority, t.UserID, t.CreatedAt, t.UpdatedAt,
       u.FullName, u.Email, u.Role, u.Phone, u.CreatedAt AS UserCreatedAt
FROM Tickets AS t
LEFT JOIN Users AS u ON t.UserID = u.ID";

        if (userId.HasValue)
        {
            command.CommandText += " WHERE t.UserID = ?";
            command.Parameters.AddWithValue("@UserID", userId.Value);
        }

        command.CommandText += " ORDER BY t.CreatedAt DESC";
        using var reader = command.ExecuteReader();
        var tickets = new List<TicketDto>();
        while (reader != null && reader.Read())
        {
            tickets.Add(MapTicket(reader));
        }

        return tickets;
    }

    public TicketDto CreateTicket(string title, string description, string status, string priority, int userId)
    {
        using var connection = OpenConnection();
        using var cmd = connection.CreateCommand();
        var now = DateTime.Now;
        cmd.CommandText = @"INSERT INTO Tickets (Title, Description, Status, Priority, UserID, CreatedAt, UpdatedAt)
VALUES (?, ?, ?, ?, ?, ?, ?)";
        cmd.Parameters.Add("@Title", OleDbType.VarWChar, 180).Value = title;
        cmd.Parameters.Add("@Description", OleDbType.LongVarWChar).Value = description;
        cmd.Parameters.Add("@Status", OleDbType.VarWChar, 40).Value = status;
        cmd.Parameters.Add("@Priority", OleDbType.VarWChar, 20).Value = priority;
        cmd.Parameters.Add("@UserID", OleDbType.Integer).Value = userId;
        cmd.Parameters.Add("@CreatedAt", OleDbType.Date).Value = now;
        cmd.Parameters.Add("@UpdatedAt", OleDbType.Date).Value = now;
        cmd.ExecuteNonQuery();

        var id = GetIdentity(connection);
        return GetTicketById(connection, id)!;
    }

    public TicketDto? UpdateTicket(int ticketId, string title, string description, string status, string priority, int userId)
    {
        using var connection = OpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"UPDATE Tickets
SET Title = ?, Description = ?, Status = ?, Priority = ?, UserID = ?, UpdatedAt = ?
WHERE ID = ?";
        cmd.Parameters.Add("@Title", OleDbType.VarWChar, 180).Value = title;
        cmd.Parameters.Add("@Description", OleDbType.LongVarWChar).Value = description;
        cmd.Parameters.Add("@Status", OleDbType.VarWChar, 40).Value = status;
        cmd.Parameters.Add("@Priority", OleDbType.VarWChar, 20).Value = priority;
        cmd.Parameters.Add("@UserID", OleDbType.Integer).Value = userId;
        cmd.Parameters.Add("@UpdatedAt", OleDbType.Date).Value = DateTime.Now;
        cmd.Parameters.Add("@ID", OleDbType.Integer).Value = ticketId;
        cmd.ExecuteNonQuery();
        return GetTicketById(connection, ticketId);
    }

    public void DeleteTicket(int ticketId)
    {
        using var connection = OpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM Tickets WHERE ID = ?";
        cmd.Parameters.AddWithValue("@ID", ticketId);
        cmd.ExecuteNonQuery();
    }

    private OleDbConnection OpenConnection()
    {
        var connection = new OleDbConnection(_connectionString);
        connection.Open();
        return connection;
    }

    private static UserDto MapUser(OleDbDataReader reader) => new()
    {
        Id = Convert.ToInt32(reader["ID"]),
        FullName = reader["FullName"].ToString() ?? string.Empty,
        Email = reader["Email"].ToString() ?? string.Empty,
        Role = reader["Role"].ToString() ?? "user",
        Phone = reader["Phone"] is DBNull ? null : reader["Phone"].ToString(),
        CreatedAt = reader["CreatedAt"] is DBNull ? DateTime.MinValue : Convert.ToDateTime(reader["CreatedAt"])
    };

    private static TicketDto MapTicket(OleDbDataReader reader)
    {
        var ticket = new TicketDto
        {
            Id = Convert.ToInt32(reader["ID"]),
            Title = reader["Title"].ToString() ?? string.Empty,
            Description = reader["Description"].ToString() ?? string.Empty,
            Status = reader["Status"].ToString() ?? "open",
            Priority = reader["Priority"].ToString() ?? "normal",
            UserId = reader["UserID"] is DBNull ? 0 : Convert.ToInt32(reader["UserID"]),
            CreatedAt = reader["CreatedAt"] is DBNull ? DateTime.MinValue : Convert.ToDateTime(reader["CreatedAt"]),
            UpdatedAt = reader["UpdatedAt"] is DBNull ? DateTime.MinValue : Convert.ToDateTime(reader["UpdatedAt"])
        };

        if (reader["FullName"] != DBNull.Value)
        {
            ticket.User = new UserDto
            {
                Id = ticket.UserId,
                FullName = reader["FullName"].ToString() ?? string.Empty,
                Email = reader["Email"].ToString() ?? string.Empty,
                Role = reader["Role"].ToString() ?? "user",
                Phone = reader["Phone"] is DBNull ? null : reader["Phone"].ToString(),
                CreatedAt = reader["UserCreatedAt"] is DBNull ? DateTime.MinValue : Convert.ToDateTime(reader["UserCreatedAt"])
            };
        }

        return ticket;
    }

    private static UserDto? GetUserById(OleDbConnection connection, int id)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT ID, FullName, Email, Role, Phone, CreatedAt FROM Users WHERE ID = ?";
        cmd.Parameters.AddWithValue("@ID", id);
        using var reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
        return reader != null && reader.Read() ? MapUser(reader) : null;
    }

    private static TicketDto? GetTicketById(OleDbConnection connection, int id)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"
SELECT t.ID, t.Title, t.Description, t.Status, t.Priority, t.UserID, t.CreatedAt, t.UpdatedAt,
       u.FullName, u.Email, u.Role, u.Phone, u.CreatedAt AS UserCreatedAt
FROM Tickets AS t
LEFT JOIN Users AS u ON t.UserID = u.ID
WHERE t.ID = ?";
        cmd.Parameters.AddWithValue("@ID", id);
        using var reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
        return reader != null && reader.Read() ? MapTicket(reader) : null;
    }

    private static int GetIdentity(OleDbConnection connection)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT @@IDENTITY";
        return Convert.ToInt32(cmd.ExecuteScalar());
    }
}

