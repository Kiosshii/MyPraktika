using System.ComponentModel;
using System.Drawing;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;

namespace PomogSlonyare.Client;

public class MyTicketsForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly UserDto _user;
    private readonly BindingList<TicketDto> _tickets = new();
    private readonly DataGridView _grid = new();

    public MyTicketsForm(PomogSlonyareRepository repository, UserDto user)
    {
        _repository = repository;
        _user = user;
        InitializeUi();
    }

    private void InitializeUi()
    {
        Text = "Мои заявки";
        BackColor = Color.FromArgb(15, 26, 43);
        ForeColor = Color.White;
        Width = 840;
        Height = 520;
        StartPosition = FormStartPosition.CenterParent;

        _grid.Dock = DockStyle.Fill;
        _grid.DataSource = _tickets;
        _grid.ReadOnly = true;
        _grid.AutoGenerateColumns = false;
        _grid.BackgroundColor = Color.FromArgb(32, 46, 74);
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(64, 77, 117);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.EnableHeadersVisualStyles = false;

        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.Title), HeaderText = "Заголовок", Width = 200 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.Status), HeaderText = "Статус", Width = 120 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.Priority), HeaderText = "Приоритет", Width = 120 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.CreatedAt), HeaderText = "Создано", Width = 150 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.UpdatedAt), HeaderText = "Обновлено", Width = 150 });

        var btnRefresh = new Button
        {
            Text = "Обновить",
            Dock = DockStyle.Bottom,
            Height = 50,
            BackColor = Color.FromArgb(88, 196, 209),
            FlatStyle = FlatStyle.Flat,
            ForeColor = Color.White
        };
        btnRefresh.FlatAppearance.BorderSize = 0;
        btnRefresh.Click += async (_, _) => await LoadTicketsAsync();

        Controls.Add(_grid);
        Controls.Add(btnRefresh);

        Shown += async (_, _) => await LoadTicketsAsync();
    }

    private async Task LoadTicketsAsync()
    {
        try
        {
            UseWaitCursor = true;
            var items = await Task.Run(() => _repository.GetTickets(_user.Id));

            _tickets.Clear();
            foreach (var ticket in items)
            {
                _tickets.Add(ticket);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }
}

