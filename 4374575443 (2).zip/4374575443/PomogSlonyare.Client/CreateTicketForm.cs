using System.Drawing;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;
using PomogSlonyare.Shared.UI;

namespace PomogSlonyare.Client;

public class CreateTicketForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly UserDto _user;

    private readonly TextBox _title = new() { Width = 320 };
    private readonly TextBox _description = new() { Width = 320, Height = 150, Multiline = true, ScrollBars = ScrollBars.Vertical };
    private readonly ComboBox _priority = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 150 };
    private readonly Button _submit = new();

    public CreateTicketForm(PomogSlonyareRepository repository, UserDto user)
    {
        _repository = repository;
        _user = user;
        InitializeUi();
        DialogStyler.ApplySmoothDialog(this);
    }

    private void InitializeUi()
    {
        Text = "Новая заявка";
        BackColor = Color.FromArgb(18, 26, 43);
        ForeColor = Color.White;
        Padding = new Padding(20);
        StartPosition = FormStartPosition.CenterParent;

        _priority.Items.AddRange(new[] { "low", "normal", "high" });
        _priority.SelectedIndex = 1;

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        AddRow(layout, "Заголовок *", _title);
        AddRow(layout, "Описание *", _description);
        AddRow(layout, "Приоритет", _priority);

        _submit.Text = "Отправить";
        _submit.BackColor = Color.FromArgb(94, 111, 255);
        _submit.FlatStyle = FlatStyle.Flat;
        _submit.FlatAppearance.BorderSize = 0;
        _submit.Height = 45;
        _submit.Click += async (_, _) => await SubmitAsync();

        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        actions.Controls.Add(_submit);
        layout.Controls.Add(actions, 0, layout.RowCount);
        layout.SetColumnSpan(actions, 2);

        Controls.Add(layout);
    }

    private static void AddRow(TableLayoutPanel table, string label, Control control)
    {
        var lbl = new Label { Text = label, AutoSize = true, Margin = new Padding(0, 10, 10, 0) };
        table.Controls.Add(lbl);
        table.Controls.Add(control);
        table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
    }

    private async Task SubmitAsync()
    {
        if (string.IsNullOrWhiteSpace(_title.Text) || string.IsNullOrWhiteSpace(_description.Text))
        {
            MessageBox.Show(this, "Заполните обязательные поля", "Валидация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            _submit.Enabled = false;
            var title = _title.Text;
            var description = _description.Text;
            var priority = _priority.SelectedItem?.ToString() ?? "normal";
            var userId = _user.Id;

            await Task.Run(() => _repository.CreateTicket(
                title,
                description,
                "open",
                priority,
                userId));

            MessageBox.Show(this, "Заявка успешно создана! Мы скоро ответим.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _submit.Enabled = true;
        }
    }
}

