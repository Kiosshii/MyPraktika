﻿using System.Drawing;
using System.Windows.Forms;

namespace PomogSlonyare.Client;

partial class LandingForm
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblHeroTitle = null!;
    private Label lblHeroSubtitle = null!;
    private Button btnRegister = null!;
    private Button btnLogin = null!;
    private Button btnExit = null!;
    private FlowLayoutPanel buttonLayout = null!;
    private TableLayoutPanel mainLayout = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        SuspendLayout();

        BackColor = Color.FromArgb(11, 24, 38);
        ForeColor = Color.White;
        ClientSize = new Size(860, 540);
        Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
        StartPosition = FormStartPosition.CenterScreen;
        AutoScaleMode = AutoScaleMode.None;

        mainLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(40, 20, 40, 30),
            BackColor = Color.Transparent
        };
        mainLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        mainLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

        lblHeroTitle = new Label
        {
            AutoSize = false,
            Dock = DockStyle.Top,
            Height = 90,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI Semibold", 40F, FontStyle.Bold, GraphicsUnit.Point),
            ForeColor = Color.FromArgb(255, 214, 165)
        };

        lblHeroSubtitle = new Label
        {
            AutoSize = false,
            Dock = DockStyle.Top,
            Height = 60,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point),
            ForeColor = Color.Gainsboro
        };

        buttonLayout = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(0, 10, 0, 0),
            Margin = new Padding(0),
            BackColor = Color.Transparent
        };

        btnRegister = CreateActionButton(Color.FromArgb(94, 111, 255));
        btnRegister.Click += btnRegister_Click;

        btnLogin = CreateActionButton(Color.FromArgb(88, 196, 209));
        btnLogin.Click += btnLogin_Click;

        btnExit = CreateActionButton(Color.FromArgb(255, 149, 128));
        btnExit.Click += btnExit_Click;

        buttonLayout.Controls.Add(btnRegister);
        buttonLayout.Controls.Add(btnLogin);
        buttonLayout.Controls.Add(btnExit);

        mainLayout.Controls.Add(lblHeroTitle, 0, 0);
        mainLayout.Controls.Add(lblHeroSubtitle, 0, 1);
        mainLayout.Controls.Add(buttonLayout, 0, 2);

        Controls.Add(mainLayout);
        ResumeLayout(false);
    }

    private static Button CreateActionButton(Color color) =>
        new()
        {
            Height = 60,
            Width = 260,
            Margin = new Padding(0, 18, 0, 0),
            FlatStyle = FlatStyle.Flat,
            BackColor = color,
            ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point),
            FlatAppearance = { BorderSize = 0 }
        };
}
