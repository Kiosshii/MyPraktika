using PomogSlonyare.Admin;
using PomogSlonyare.Shared.Services;

namespace PomogSlonyare.Client;

public partial class LandingForm : Form
{
    private readonly PomogSlonyareRepository _repository = new();

    public LandingForm()
    {
        InitializeComponent();
        Text = "PomogSlonyare • Клиентская поддержка";
        lblHeroTitle.Text = "PomogSlonyare";
        lblHeroSubtitle.Text = "Подайте заявку и получите помощь команды поддержки";
        btnRegister.Text = "Зарегистрироваться";
        btnLogin.Text = "Войти";
        btnExit.Text = "Выйти";
    }

    private void btnRegister_Click(object? sender, EventArgs e)
    {
        using var registerForm = new RegisterForm(_repository);
        registerForm.ShowDialog(this);
    }

    private void btnLogin_Click(object? sender, EventArgs e)
    {
        using var loginForm = new LoginForm(_repository);
        if (loginForm.ShowDialog(this) != DialogResult.OK || loginForm.AuthenticatedUser is null)
        {
            return;
        }

        var currentUser = loginForm.AuthenticatedUser;
        if (string.Equals(currentUser.Role, "admin", StringComparison.OrdinalIgnoreCase))
        {
            Hide();
            using var adminPanel = new AdminMainForm();
            adminPanel.ShowDialog(this);
            Show();
        }
        else
        {
            using var dashboard = new DashboardForm(_repository, currentUser);
            dashboard.ShowDialog(this);
        }
    }

    private void btnExit_Click(object? sender, EventArgs e) => Close();
}
