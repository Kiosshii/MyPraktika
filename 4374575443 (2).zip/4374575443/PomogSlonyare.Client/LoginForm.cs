using System.Drawing;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;
using PomogSlonyare.Shared.UI;

namespace PomogSlonyare.Client;

public class LoginForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly TextBox _email = new() { Width = 260 };
    private readonly TextBox _password = new() { Width = 260, UseSystemPasswordChar = true };
    private readonly Button _submit = new();

    public UserDto? AuthenticatedUser { get; private set; }

    public LoginForm(PomogSlonyareRepository repository)
    {
        _repository = repository;
        InitializeUi();
        DialogStyler.ApplySmoothDialog(this);
    }

    private void InitializeUi()
    {
        Text = "Вход в PomogSlonyare";
        BackColor = Color.FromArgb(18, 24, 38);
        ForeColor = Color.White;
        Padding = new Padding(20);
        StartPosition = FormStartPosition.CenterParent;

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            AutoSize = true
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        AddRow(layout, "E-mail", _email);
        AddRow(layout, "Пароль", _password);

        _submit.Text = "Войти";
        _submit.BackColor = Color.FromArgb(94, 111, 255);
        _submit.FlatStyle = FlatStyle.Flat;
        _submit.FlatAppearance.BorderSize = 0;
        _submit.Height = 45;
        _submit.Click += async (_, _) => await LoginAsync();

        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        actions.Controls.Add(_submit);

        layout.Controls.Add(actions, 0, layout.RowCount);
        layout.SetColumnSpan(actions, 2);

        Controls.Add(layout);
    }

    private static void AddRow(TableLayoutPanel table, string label, Control control)
    {
        var lbl = new Label { Text = label, AutoSize = true, Margin = new Padding(0, 10, 10, 0) };
        table.Controls.Add(lbl);
        table.Controls.Add(control);
        table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
    }

    private async Task LoginAsync()
    {
        if (string.IsNullOrWhiteSpace(_email.Text) || string.IsNullOrWhiteSpace(_password.Text))
        {
            MessageBox.Show(this, "Введите e-mail и пароль", "Валидация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            _submit.Enabled = false;
            var user = await Task.Run(() => _repository.Authenticate(_email.Text, _password.Text));
            if (user is null)
            {
                MessageBox.Show(this, "Неверный e-mail или пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            AuthenticatedUser = user;
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _submit.Enabled = true;
        }
    }
}

