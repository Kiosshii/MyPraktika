using System.Drawing;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;

namespace PomogSlonyare.Client;

public class DashboardForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly UserDto _user;
    private readonly Label _greeting = new();

    public DashboardForm(PomogSlonyareRepository repository, UserDto user)
    {
        _repository = repository;
        _user = user;
        InitializeUi();
    }

    private void InitializeUi()
    {
        Text = "PomogSlonyare • Кабинет пользователя";
        BackColor = Color.FromArgb(16, 30, 49);
        ForeColor = Color.White;
        ClientSize = new Size(780, 480);
        StartPosition = FormStartPosition.CenterParent;

        _greeting.Text = $"Здравствуйте, {_user.FullName}!";
        _greeting.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point);
        _greeting.Dock = DockStyle.Top;
        _greeting.Height = 100;
        _greeting.TextAlign = ContentAlignment.MiddleCenter;

        var btnCreate = CreateButton("Оставить заявку", (_, _) => OpenCreateTicket());
        var btnMyTickets = CreateButton("Мои заявки", (_, _) => OpenMyTickets());
        var btnClose = CreateButton("Выйти", (_, _) => Close());

        var infoPanel = new Panel { Dock = DockStyle.Top, Height = 80, Padding = new Padding(20) };
        var lblInfo = new Label
        {
            Text = $"Ваш e-mail: {_user.Email}\nРоль: {_user.Role}",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        };
        infoPanel.Controls.Add(lblInfo);

        var buttonLayout = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            Padding = new Padding(80, 10, 80, 30),
            WrapContents = false,
            AutoScroll = true
        };
        buttonLayout.Controls.Add(btnCreate);
        buttonLayout.Controls.Add(btnMyTickets);
        buttonLayout.Controls.Add(btnClose);

        var container = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 3,
            ColumnCount = 1,
            Padding = new Padding(30, 20, 30, 30)
        };
        container.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        container.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        container.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        container.Controls.Add(_greeting, 0, 0);
        container.Controls.Add(infoPanel, 0, 1);
        container.Controls.Add(buttonLayout, 0, 2);

        Controls.Add(container);
    }

    private Button CreateButton(string text, EventHandler handler)
    {
        var button = new Button
        {
            Text = text,
            Height = 70,
            Margin = new Padding(0, 20, 0, 0),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(88, 196, 209),
            ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold, GraphicsUnit.Point),
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += handler;
        return button;
    }

    private void OpenCreateTicket()
    {
        using var form = new CreateTicketForm(_repository, _user);
        form.ShowDialog(this);
    }

    private void OpenMyTickets()
    {
        using var form = new MyTicketsForm(_repository, _user);
        form.ShowDialog(this);
    }
}

