using System.ComponentModel;
using System.Drawing;
using System.Linq;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;

namespace PomogSlonyare.Admin;

public class TicketManagementForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly BindingList<TicketDto> _tickets = new();
    private readonly DataGridView _grid = new();

    public TicketManagementForm(PomogSlonyareRepository repository)
    {
        _repository = repository;
        InitializeUi();
    }

    private void InitializeUi()
    {
        Text = "Заявки технической поддержки";
        Width = 1000;
        Height = 620;
        BackColor = Color.FromArgb(18, 28, 45);
        ForeColor = Color.White;
        StartPosition = FormStartPosition.CenterParent;

        var mainLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 2,
            ColumnCount = 1
        };
        mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 90));
        mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 10));

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AutoGenerateColumns = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.BackgroundColor = Color.FromArgb(32, 46, 74);
        _grid.EnableHeadersVisualStyles = false;
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(64, 77, 117);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.DataSource = _tickets;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.Title), HeaderText = "Заголовок", Width = 200 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.Status), HeaderText = "Статус", Width = 120 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.Priority), HeaderText = "Приоритет", Width = 120 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.CreatedAt), HeaderText = "Создано", Width = 150 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(TicketDto.UpdatedAt), HeaderText = "Обновлено", Width = 150 });

        var btnPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(10)
        };

        var btnRefresh = CreateButton("Обновить", async (_, _) => await LoadTicketsAsync());
        var btnDelete = CreateButton("Удалить", async (_, _) => await DeleteAsync());
        var btnEdit = CreateButton("Изменить", async (_, _) => await OpenEditorAsync(false));
        var btnAdd = CreateButton("Добавить", async (_, _) => await OpenEditorAsync(true));

        btnPanel.Controls.AddRange(new Control[] { btnRefresh, btnDelete, btnEdit, btnAdd });

        mainLayout.Controls.Add(_grid, 0, 0);
        mainLayout.Controls.Add(btnPanel, 0, 1);
        Controls.Add(mainLayout);

        Shown += async (_, _) => await LoadTicketsAsync();
    }

    private Button CreateButton(string text, EventHandler handler)
    {
        var button = new Button
        {
            Text = text,
            BackColor = Color.FromArgb(255, 149, 128),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(10),
            Width = 150,
            Height = 50
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += handler;
        return button;
    }

    private async Task LoadTicketsAsync()
    {
        try
        {
            UseWaitCursor = true;
            var result = await Task.Run(() => _repository.GetTickets());

            _tickets.Clear();
            foreach (var ticket in result)
            {
                _tickets.Add(ticket);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }

    private TicketDto? CurrentTicket => _grid.CurrentRow?.DataBoundItem as TicketDto;

    private async Task OpenEditorAsync(bool isNew)
    {
        TicketDto? ticket = null;
        if (!isNew)
        {
            ticket = CurrentTicket;
            if (ticket is null)
            {
                MessageBox.Show(this, "Выберите заявку", "Подсказка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        List<UserDto> users;
        try
        {
            users = await Task.Run(() => _repository.GetUsers().ToList());
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"Ошибка загрузки пользователей: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        using var editor = new TicketEditorForm(_repository, users, ticket);
        if (editor.ShowDialog(this) == DialogResult.OK)
        {
            await LoadTicketsAsync();
        }
    }

    private async Task DeleteAsync()
    {
        var ticket = CurrentTicket;
        if (ticket is null)
        {
            MessageBox.Show(this, "Ничего не выбрано", "Подсказка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (MessageBox.Show(this, $"Удалить заявку '{ticket.Title}'?", "Подтвердите", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
        {
            return;
        }

        try
        {
            await Task.Run(() => _repository.DeleteTicket(ticket.Id));
            _tickets.Remove(ticket);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}

