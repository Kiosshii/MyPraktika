using PomogSlonyare.Shared.Services;

namespace PomogSlonyare.Admin;

public partial class AdminMainForm : Form
{
    private readonly PomogSlonyareRepository _repository = new();

    public AdminMainForm()
    {
        InitializeComponent();
        DoubleBuffered = true;
        MinimumSize = new Size(780, 520);
        Text = "PomogSlonyare • Панель администратора";
        lblTitle.Text = "PomogSlonyare";
        lblSubtitle.Text = "Центр управления технической поддержкой";
        btnUsers.Text = "Пользователи";
        btnTickets.Text = "Заявки";
        btnAbout.Text = "О системе";
    }

    private void btnUsers_Click(object? sender, EventArgs e)
    {
        using var form = new UserManagementForm(_repository);
        form.ShowDialog(this);
    }

    private void btnTickets_Click(object? sender, EventArgs e)
    {
        using var form = new TicketManagementForm(_repository);
        form.ShowDialog(this);
    }

    private void btnAbout_Click(object? sender, EventArgs e)
    {
        MessageBox.Show(
            this,
            "PomogSlonyare помогает командам поддержки быстро работать с обращениями клиентов.\n\n" +
            "Версия администратора — для управления пользователями и заявками.\n" +
            "Клиентское приложение — для регистрации и подачи обращений.",
            "О системе",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }
}
