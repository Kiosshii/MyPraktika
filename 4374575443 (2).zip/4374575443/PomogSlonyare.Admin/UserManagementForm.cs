using System.ComponentModel;
using System.Drawing;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;

namespace PomogSlonyare.Admin;

public class UserManagementForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly BindingList<UserDto> _users = new();
    private readonly DataGridView _grid = new();
    private readonly ToolStripStatusLabel _statusLabel = new();

    public UserManagementForm(PomogSlonyareRepository repository)
    {
        _repository = repository;
        InitializeUi();
    }

    private void InitializeUi()
    {
        Text = "Управление пользователями";
        Width = 900;
        Height = 600;
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(24, 34, 54);
        ForeColor = Color.White;

        var mainPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 2,
            ColumnCount = 1
        };
        mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 90));
        mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 10));

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AutoGenerateColumns = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.BackgroundColor = Color.FromArgb(32, 46, 74);
        _grid.ForeColor = Color.Black;
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(64, 77, 117);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.EnableHeadersVisualStyles = false;
        _grid.DataSource = _users;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(UserDto.FullName), HeaderText = "ФИО", Width = 200 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(UserDto.Email), HeaderText = "E-mail", Width = 200 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(UserDto.Role), HeaderText = "Роль", Width = 80 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(UserDto.Phone), HeaderText = "Телефон", Width = 150 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(UserDto.CreatedAt), HeaderText = "Создан", Width = 150 });

        var buttonPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(10)
        };

        var btnRefresh = CreateButton("Обновить", async (_, _) => await LoadUsersAsync());
        var btnDelete = CreateButton("Удалить", async (_, _) => await DeleteSelectedAsync());
        var btnEdit = CreateButton("Изменить", (_, _) => OpenEditor(false));
        var btnAdd = CreateButton("Добавить", (_, _) => OpenEditor(true));

        buttonPanel.Controls.AddRange(new Control[] { btnRefresh, btnDelete, btnEdit, btnAdd });

        var statusStrip = new StatusStrip { Dock = DockStyle.Fill, SizingGrip = false };
        statusStrip.Items.Add(_statusLabel);

        mainPanel.Controls.Add(_grid, 0, 0);
        mainPanel.Controls.Add(buttonPanel, 0, 1);

        Controls.Add(mainPanel);
        Controls.Add(statusStrip);

        Shown += async (_, _) => await LoadUsersAsync();
    }

    private Button CreateButton(string text, EventHandler handler)
    {
        var button = new Button
        {
            Text = text,
            BackColor = Color.FromArgb(94, 111, 255),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(10),
            Width = 150,
            Height = 50
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += handler;
        return button;
    }

    private async Task LoadUsersAsync()
    {
        try
        {
            UseWaitCursor = true;
            _statusLabel.Text = "Загрузка...";
            var items = await Task.Run(() => _repository.GetUsers());

            _users.Clear();
            foreach (var user in items)
            {
                _users.Add(user);
            }
            _statusLabel.Text = $"Всего пользователей: {_users.Count}";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"Ошибка загрузки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }

    private void OpenEditor(bool isNew)
    {
        UserDto? selected = null;
        if (!isNew)
        {
            selected = GetSelectedUser();
            if (selected is null)
            {
                MessageBox.Show(this, "Выберите пользователя", "Подсказка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        using var form = new UserEditorForm(_repository, selected);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            _ = LoadUsersAsync();
        }
    }

    private async Task DeleteSelectedAsync()
    {
        var selected = GetSelectedUser();
        if (selected is null)
        {
            MessageBox.Show(this, "Ничего не выбрано", "Подсказка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (MessageBox.Show(this, $"Удалить пользователя {selected.FullName}?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
        {
            return;
        }

        try
        {
            await Task.Run(() => _repository.DeleteUser(selected.Id));
            _users.Remove(selected);
            _statusLabel.Text = $"Всего пользователей: {_users.Count}";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private UserDto? GetSelectedUser()
    {
        if (_grid.CurrentRow?.DataBoundItem is UserDto user)
        {
            return user;
        }

        return null;
    }
}

