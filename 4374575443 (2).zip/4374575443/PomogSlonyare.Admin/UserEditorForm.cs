using System.Drawing;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;
using PomogSlonyare.Shared.UI;

namespace PomogSlonyare.Admin;

public class UserEditorForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly UserDto? _user;

    private readonly TextBox _fullName = new() { Width = 260 };
    private readonly TextBox _email = new() { Width = 260 };
    private readonly TextBox _password = new() { Width = 260, UseSystemPasswordChar = true };
    private readonly ComboBox _role = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 260 };
    private readonly TextBox _phone = new() { Width = 260 };
    private readonly Button _saveButton = new();

    public UserEditorForm(PomogSlonyareRepository repository, UserDto? user)
    {
        _repository = repository;
        _user = user;
        InitializeUi();
        DialogStyler.ApplySmoothDialog(this);
    }

    private void InitializeUi()
    {
        Text = _user is null ? "Добавить пользователя" : "Редактировать пользователя";
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(28, 40, 62);
        ForeColor = Color.White;
        Padding = new Padding(20);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 6,
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        AddRow(layout, "ФИО", _fullName);
        AddRow(layout, "E-mail", _email);
        AddRow(layout, "Пароль", _password);
        AddRow(layout, "Роль", _role);
        AddRow(layout, "Телефон", _phone);

        _role.Items.AddRange(new[] { "user", "admin" });

        _saveButton.Text = "Сохранить";
        _saveButton.BackColor = Color.FromArgb(94, 111, 255);
        _saveButton.FlatStyle = FlatStyle.Flat;
        _saveButton.FlatAppearance.BorderSize = 0;
        _saveButton.Height = 45;
        _saveButton.Click += async (_, _) => await SaveAsync();

        var buttonPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        buttonPanel.Controls.Add(_saveButton);

        layout.Controls.Add(buttonPanel, 0, layout.RowCount);
        layout.SetColumnSpan(buttonPanel, 2);

        Controls.Add(layout);

        if (_user is not null)
        {
            _fullName.Text = _user.FullName;
            _email.Text = _user.Email;
            _role.SelectedItem = _user.Role;
            _phone.Text = _user.Phone;
        }
        else
        {
            _role.SelectedIndex = 0;
        }
    }

    private static void AddRow(TableLayoutPanel panel, string label, Control control)
    {
        var lbl = new Label
        {
            Text = label,
            AutoSize = true,
            Margin = new Padding(0, 10, 10, 0)
        };
        panel.Controls.Add(lbl);
        panel.Controls.Add(control);
        panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
    }

    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(_fullName.Text) || string.IsNullOrWhiteSpace(_email.Text))
        {
            MessageBox.Show(this, "Поля ФИО и e-mail обязательны", "Валидация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            _saveButton.Enabled = false;
            var role = _role.SelectedItem?.ToString() ?? "user";
            if (_user is null)
            {
                var password = string.IsNullOrWhiteSpace(_password.Text) ? "ChangeMe123" : _password.Text;
                await Task.Run(() => _repository.CreateUser(_fullName.Text, _email.Text, password, role, _phone.Text));
            }
            else
            {
                var password = string.IsNullOrWhiteSpace(_password.Text) ? null : _password.Text;
                await Task.Run(() => _repository.UpdateUser(_user.Id, _fullName.Text, _email.Text, role, _phone.Text, password));
            }

            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _saveButton.Enabled = true;
        }
    }
}

