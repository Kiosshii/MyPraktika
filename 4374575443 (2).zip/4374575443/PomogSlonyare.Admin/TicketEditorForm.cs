using System.Drawing;
using PomogSlonyare.Shared.Models;
using PomogSlonyare.Shared.Services;
using PomogSlonyare.Shared.UI;

namespace PomogSlonyare.Admin;

public class TicketEditorForm : Form
{
    private readonly PomogSlonyareRepository _repository;
    private readonly IReadOnlyList<UserDto> _users;
    private readonly TicketDto? _ticket;

    private readonly TextBox _title = new() { Width = 280 };
    private readonly TextBox _description = new() { Width = 280, Height = 120, Multiline = true, ScrollBars = ScrollBars.Vertical };
    private readonly ComboBox _priority = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 200 };
    private readonly ComboBox _status = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 200 };
    private readonly ComboBox _userSelect = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 280 };
    private readonly Button _saveButton = new();

    public TicketEditorForm(PomogSlonyareRepository repository, IReadOnlyList<UserDto> users, TicketDto? ticket)
    {
        _repository = repository;
        _users = users;
        _ticket = ticket;
        InitializeUi();
        DialogStyler.ApplySmoothDialog(this);
    }

    private void InitializeUi()
    {
        Text = _ticket is null ? "Новая заявка" : "Редактирование заявки";
        BackColor = Color.FromArgb(22, 32, 51);
        ForeColor = Color.White;
        Padding = new Padding(20);
        StartPosition = FormStartPosition.CenterParent;

        foreach (var user in _users)
        {
            _userSelect.Items.Add(new ComboBoxItem(user.FullName, user.Id));
        }

        _priority.Items.AddRange(new[] { "low", "normal", "high" });
        _status.Items.AddRange(new[] { "open", "in_progress", "closed" });

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 6,
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        AddRow(layout, "Заголовок", _title);
        AddRow(layout, "Описание", _description);
        AddRow(layout, "Приоритет", _priority);
        AddRow(layout, "Статус", _status);
        AddRow(layout, "Пользователь", _userSelect);

        _saveButton.Text = "Сохранить";
        _saveButton.BackColor = Color.FromArgb(255, 149, 128);
        _saveButton.FlatStyle = FlatStyle.Flat;
        _saveButton.FlatAppearance.BorderSize = 0;
        _saveButton.Height = 45;
        _saveButton.Click += async (_, _) => await SaveAsync();

        var buttonPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        buttonPanel.Controls.Add(_saveButton);

        layout.Controls.Add(buttonPanel, 0, layout.RowCount);
        layout.SetColumnSpan(buttonPanel, 2);

        Controls.Add(layout);

        if (_ticket is not null)
        {
            _title.Text = _ticket.Title;
            _description.Text = _ticket.Description;
            _priority.SelectedItem = _ticket.Priority;
            _status.SelectedItem = _ticket.Status;
            SelectUser(_ticket.UserId);
        }
        else
        {
            _priority.SelectedItem = "normal";
            _status.SelectedItem = "open";
            if (_userSelect.Items.Count > 0)
            {
                _userSelect.SelectedIndex = 0;
            }
        }
    }

    private void SelectUser(int userId)
    {
        for (var i = 0; i < _userSelect.Items.Count; i++)
        {
            if (_userSelect.Items[i] is ComboBoxItem item && item.Value == userId)
            {
                _userSelect.SelectedIndex = i;
                return;
            }
        }
    }

    private static void AddRow(TableLayoutPanel panel, string label, Control control)
    {
        var lbl = new Label
        {
            Text = label,
            AutoSize = true,
            Margin = new Padding(0, 10, 10, 0)
        };
        panel.Controls.Add(lbl);
        panel.Controls.Add(control);
        panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
    }

    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(_title.Text) || string.IsNullOrWhiteSpace(_description.Text))
        {
            MessageBox.Show(this, "Заполните заголовок и описание", "Валидация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (_userSelect.SelectedItem is not ComboBoxItem userItem)
        {
            MessageBox.Show(this, "Выберите пользователя", "Валидация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            _saveButton.Enabled = false;
            var title = _title.Text;
            var description = _description.Text;
            var priority = _priority.SelectedItem?.ToString() ?? "normal";
            var status = _status.SelectedItem?.ToString() ?? "open";
            var userId = userItem.Value;

            if (_ticket is null)
            {
                await Task.Run(() => _repository.CreateTicket(title, description, status, priority, userId));
            }
            else
            {
                await Task.Run(() => _repository.UpdateTicket(_ticket.Id, title, description, status, priority, userId));
            }

            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _saveButton.Enabled = true;
        }
    }

    private sealed record ComboBoxItem(string Text, int Value)
    {
        public override string ToString() => Text;
    }
}

