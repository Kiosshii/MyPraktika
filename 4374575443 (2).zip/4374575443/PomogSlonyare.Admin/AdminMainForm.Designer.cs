﻿using System.Drawing;
using System.Windows.Forms;

namespace PomogSlonyare.Admin;

partial class AdminMainForm
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitle = null!;
    private Label lblSubtitle = null!;
    private Button btnUsers = null!;
    private Button btnTickets = null!;
    private Button btnAbout = null!;
    private Panel headerPanel = null!;
    private FlowLayoutPanel buttonsFlow = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        SuspendLayout();

        BackColor = Color.FromArgb(18, 24, 38);
        ForeColor = Color.White;
        ClientSize = new Size(900, 560);
        Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
        StartPosition = FormStartPosition.CenterScreen;

        headerPanel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 150,
            BackColor = Color.FromArgb(32, 46, 74)
        };

        lblTitle = new Label
        {
            AutoSize = false,
            Dock = DockStyle.Top,
            Height = 70,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI Semibold", 36F, FontStyle.Bold, GraphicsUnit.Point),
            ForeColor = Color.FromArgb(255, 214, 165)
        };

        lblSubtitle = new Label
        {
            AutoSize = false,
            Dock = DockStyle.Top,
            Height = 50,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point),
            ForeColor = Color.Gainsboro
        };

        headerPanel.Controls.Add(lblSubtitle);
        headerPanel.Controls.Add(lblTitle);
        Controls.Add(headerPanel);

        buttonsFlow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(30, 90, 30, 40),
            BackColor = Color.FromArgb(24, 34, 54),
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            AutoScroll = true,
            MinimumSize = new Size(0, 300)
        };

        btnUsers = CreateActionButton(Color.FromArgb(94, 111, 255));
        btnUsers.Click += btnUsers_Click;

        btnTickets = CreateActionButton(Color.FromArgb(255, 149, 128));
        btnTickets.Click += btnTickets_Click;

        btnAbout = CreateActionButton(Color.FromArgb(88, 196, 209));
        btnAbout.Click += btnAbout_Click;

        buttonsFlow.Controls.Add(btnUsers);
        buttonsFlow.Controls.Add(btnTickets);
        buttonsFlow.Controls.Add(btnAbout);
        Controls.Add(buttonsFlow);

        ResumeLayout(false);
    }

    private static Button CreateActionButton(Color color)
    {
        return new Button
        {
            Margin = new Padding(12),
            Size = new Size(250, 120),
            FlatStyle = FlatStyle.Flat,
            BackColor = color,
            ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point),
            TextAlign = ContentAlignment.MiddleCenter,
            FlatAppearance = { BorderSize = 0 }
        };
    }
}
